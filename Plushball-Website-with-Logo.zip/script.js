const banners = [
  {eyebrow:"FEATURED ART", title:"AI Plushball Art", text:"Fresh Plushball artwork can take over the homepage and keep the site feeling alive.", link:"#community", label:"See the community →"},
  {eyebrow:"9 PLATFORMS", title:"Follow Plushball", text:"Nine platforms. One community. Find your favourite place to follow.", link:"#platforms", label:"Explore platforms →"},
  {eyebrow:"YOUTUBE", title:"Latest Plushball Video", text:"The next planned upload is 20 August 2026.", link:"https://www.youtube.com/@plushball", label:"Visit YouTube ↗"},
  {eyebrow:"PLUSHBALL LABS", title:"Behind the Scenes", text:"Experiments, projects, ideas and sneak peeks from behind Plushball.", link:"#labs", label:"Enter the Labs →"},
  {eyebrow:"THE JOURNEY", title:"Milestone Progress", text:"Every follower moves Plushball closer to the next community challenge.", link:"#milestones", label:"See milestones →"}
];
let bannerIndex=0;
const $=id=>document.getElementById(id);
function showBanner(){
  const b=banners[bannerIndex];
  const el=$("rotatingBanner");
  el.style.opacity="0";
  el.style.transform="translateY(5px)";
  setTimeout(()=>{
    $("bannerEyebrow").textContent=b.eyebrow;
    $("bannerTitle").textContent=b.title;
    $("bannerText").textContent=b.text;
    $("bannerLink").textContent=b.label;
    $("bannerLink").href=b.link;
    $("bannerCount").textContent=`0${bannerIndex+1} / 05`;
    el.style.opacity="1"; el.style.transform="translateY(0)";
  },180);
}
setInterval(()=>{bannerIndex=(bannerIndex+1)%banners.length;showBanner()},5000);

const milestones=[
 [4000,"Fans choose my alarm sound"],
 [10000,"Fans choose my wallpaper"],
 [20000,"Fans choose my channel banner for 1 week"],
 [40000,"Fans choose my profile picture for 1 week"],
 [100000,"Grades Reveal"],
 [200000,"Run a Half Marathon"],
 [400000,"City Reveal"],
 [600000,"Creator Collaboration"],
 [1000000,"Voice Reveal"],
 [1600000,"Fans choose a challenge"],
 [2000000,"Fans choose a skill for me to learn"],
 [3000000,"React to something submitted by a subscriber"],
 [4000000,"Name Reveal"],
 [5000000,"Sibling Reveal — filmed"],
 [6000000,"Full Face Reveal"],
 [8000000,"Height Reveal"],
 [10000000,"Family Reveal — filmed"],
 [12000000,"12 Million Total Followers Mega Special"]
];
const currentFollowers=12450;
function renderMilestones(){
  const timeline=$("timeline");
  let next=milestones.find(m=>m[0]>currentFollowers)||milestones[milestones.length-1];
  const prev=milestones.filter(m=>m[0]<=currentFollowers).slice(-1)[0]||[0,""];
  const pct=Math.min(100,Math.max(0,((currentFollowers-prev[0])/(next[0]-prev[0]))*100));
  $("followerCount").textContent=currentFollowers.toLocaleString();
  $("nextGoal").textContent=next[0].toLocaleString();
  $("progressBar").style.width=pct+"%";
  $("progressText").textContent=pct.toFixed(1)+"% complete";
  $("followersNeeded").textContent=(next[0]-currentFollowers).toLocaleString()+" followers until the next milestone!";
  timeline.innerHTML=milestones.map(([goal,event])=>`<article class="milestone ${goal===next[0]?"current":""}"><small>${goal===next[0]?"NEXT MILESTONE":"MILESTONE"}</small><div class="goal">${goal.toLocaleString()}</div><div class="event">${event}</div></article>`).join("");
}
renderMilestones();
document.querySelector(".menu-toggle").addEventListener("click",()=>document.querySelector(".nav").classList.toggle("open"));
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>document.querySelector(".nav").classList.remove("open")));
