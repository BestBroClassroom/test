# Plushball Website

A responsive static website based on the supplied Plushball Website Plan.

## Files
- `index.html` — website structure/content
- `styles.css` — responsive design and animations
- `script.js` — rotating homepage banner, mobile navigation and milestone tracker

## Important
The follower count is currently a demo value of 12,450 and is stored in `script.js` as `currentFollowers`.
The milestone tracker is designed so this can later be replaced by a real API/CMS value.

Social URLs are based on the usernames supplied in the plan. Verify each account URL before publishing.

## Automatic integrations
A static site cannot reliably pull live YouTube/social follower data by itself. For true automatic updates, connect the site to a backend, CMS, or supported APIs.

## Logo
The supplied Plushball logo is included as `plushball-logo.jpg` and is used in the header and footer.
